import AppKit
import CoreServices
import ServiceManagement

struct StartupVolume: Equatable {
    let url: URL
    let name: String
    let version: String
    let uuid: String?
    let isCurrent: Bool

    var menuTitle: String {
        "\(name)  —  macOS \(version)" + (isCurrent ? " (en cours)" : "")
    }

    static func mounted() -> [Self] {
        let keys: [URLResourceKey] = [.volumeNameKey, .volumeUUIDStringKey,
                                      .volumeIsLocalKey, .volumeIsBrowsableKey, .isVolumeKey]
        let root = URL(fileURLWithPath: "/", isDirectory: true)
        let mounted = FileManager.default.mountedVolumeURLs(
            includingResourceValuesForKeys: keys, options: []
        ) ?? []
        let visibleMounts = (try? FileManager.default.contentsOfDirectory(
            at: URL(fileURLWithPath: "/Volumes", isDirectory: true),
            includingPropertiesForKeys: keys
        )) ?? []
        var seen = Set<String>()
        return ([root] + mounted + visibleMounts).compactMap { candidate -> Self? in
            let url = candidate.resolvingSymlinksInPath()
            let isCurrent = url.path == "/"
            guard let values = try? url.resourceValues(forKeys: Set(keys)),
                  isCurrent || (values.isVolume == true && values.volumeIsLocal == true
                                && values.volumeIsBrowsable == true)
            else { return nil }

            let versionFile = url.appendingPathComponent("System/Library/CoreServices/SystemVersion.plist")
            guard let data = try? Data(contentsOf: versionFile),
                  let versionInfo = try? PropertyListSerialization.propertyList(from: data, format: nil)
                      as? [String: Any],
                  let version = versionInfo["ProductVersion"] as? String,
                  seen.insert(values.volumeUUIDString ?? url.path).inserted
            else { return nil }

            return Self(url: url, name: values.volumeName ?? url.lastPathComponent,
                        version: version, uuid: values.volumeUUIDString, isCurrent: isCurrent)
        }.sorted {
            if $0.isCurrent != $1.isCurrent { return $0.isCurrent }
            return $0.name.localizedStandardCompare($1.name) == .orderedAscending
        }
    }
}

final class VolumeMenuItem: NSMenuItem {
    var volume: StartupVolume?
}

final class MultiBoot: NSObject, NSApplicationDelegate, NSMenuDelegate {
    private let statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.squareLength)
    private let menu = NSMenu()
    private var isWorking = false

    func applicationDidFinishLaunching(_ notification: Notification) {
        let image = Bundle.main.url(forResource: "MenuIcon", withExtension: "png")
            .flatMap { NSImage(contentsOf: $0) }
            ?? NSImage(systemSymbolName: "internaldrive", accessibilityDescription: "Multi-Boot")
        image?.size = NSSize(width: 18, height: 18)
        image?.accessibilityDescription = "Multi-Boot"
        statusItem.button?.image = image
        statusItem.button?.toolTip = "Multi-Boot"
        menu.delegate = self
        menu.autoenablesItems = false
        statusItem.menu = menu
    }

    func menuNeedsUpdate(_ menu: NSMenu) {
        menu.removeAllItems()
        if isWorking {
            addLabel("Autorisation en cours…")
            return
        }
        addLabel("Disques de démarrage")
        let volumes = StartupVolume.mounted()
        if volumes.isEmpty { addLabel("Aucun volume macOS détecté") }
        for volume in volumes {
            let item = VolumeMenuItem(title: volume.menuTitle, action: #selector(selectVolume(_:)),
                                      keyEquivalent: "")
            item.target = self
            item.volume = volume
            item.image = NSImage(systemSymbolName: "internaldrive", accessibilityDescription: nil)
            menu.addItem(item)
        }
        menu.addItem(.separator())
        addAction("Ouvrir Disque de démarrage…", #selector(openStartupSettings))

        let options = NSMenuItem(title: "Options", action: nil, keyEquivalent: "")
        let optionsMenu = NSMenu(title: "Options")
        let loginItem = NSMenuItem(title: "Boot au démarrage du système",
                                   action: #selector(toggleLaunchAtLogin), keyEquivalent: "")
        loginItem.target = self
        switch SMAppService.mainApp.status {
        case .enabled:
            loginItem.state = .on
        case .requiresApproval:
            loginItem.state = .mixed
            loginItem.toolTip = "Autorisation requise dans Réglages Système."
        default:
            loginItem.state = .off
        }
        optionsMenu.addItem(loginItem)
        options.submenu = optionsMenu
        menu.addItem(options)
        menu.addItem(.separator())
        addAction("Quitter Multi-Boot", #selector(quit))
    }

    @objc private func toggleLaunchAtLogin() {
        let service = SMAppService.mainApp
        let alert = NSAlert()
        do {
            switch service.status {
            case .enabled:
                try service.unregister()
                return
            case .requiresApproval:
                break
            default:
                try service.register()
                guard service.status != .enabled else { return }
            }
            alert.messageText = "Autoriser l’ouverture à la connexion"
            alert.informativeText = "Autorise Multi-Boot dans les réglages des éléments d’ouverture."
        } catch {
            alert.messageText = "Le réglage d’ouverture n’a pas été modifié."
            alert.informativeText = error.localizedDescription
        }
        alert.addButton(withTitle: "Ouvrir Réglages Système")
        alert.addButton(withTitle: "Fermer").keyEquivalent = "\u{1b}"
        NSApp.activate(ignoringOtherApps: true)
        if alert.runModal() == .alertFirstButtonReturn {
            SMAppService.openSystemSettingsLoginItems()
        }
    }

    private func addLabel(_ title: String) {
        let item = NSMenuItem(title: title, action: nil, keyEquivalent: "")
        item.isEnabled = false
        menu.addItem(item)
    }

    private func addAction(_ title: String, _ selector: Selector) {
        let item = NSMenuItem(title: title, action: selector, keyEquivalent: "")
        item.target = self
        menu.addItem(item)
    }

    @objc private func selectVolume(_ sender: VolumeMenuItem) {
        guard let volume = sender.volume, !isWorking else { return }
        isWorking = true
        defer { isWorking = false }

        let confirmation = NSAlert()
        confirmation.messageText = "Démarrer sur « \(volume.name) »"
        confirmation.informativeText = "Choisis quand utiliser ce disque. « Redémarrer maintenant » "
            + "en fait le disque par défaut. « Au prochain redémarrage » l’utilise une seule fois."
        confirmation.addButton(withTitle: "Redémarrer maintenant…").keyEquivalent = ""
        confirmation.addButton(withTitle: "Au prochain redémarrage").keyEquivalent = ""
        confirmation.addButton(withTitle: "Annuler").keyEquivalent = "\u{1b}"
        NSApp.activate(ignoringOtherApps: true)
        let choice = confirmation.runModal()
        guard choice == .alertFirstButtonReturn || choice == .alertSecondButtonReturn else { return }
        let nextBootOnly = choice == .alertSecondButtonReturn

        guard StartupVolume.mounted().contains(volume) else {
            showSettingsFallback("Le volume a changé ou a été déconnecté.",
                                 detail: "Rouvre le menu pour actualiser la liste.")
            return
        }

        // Standard Additions displays the macOS administrator prompt.
        // An EOF prevents bless from waiting for interactive input in a GUI process.
        let shellPath = "'" + volume.url.path.replacingOccurrences(of: "'", with: "'\\''") + "'"
        let options = nextBootOnly ? "--setBoot --nextonly" : "--setBoot"
        let command = "/usr/sbin/bless --mount \(shellPath) \(options) </dev/null"
        let literal = command.replacingOccurrences(of: "\\", with: "\\\\")
            .replacingOccurrences(of: "\"", with: "\\\"")
        var error: NSDictionary?
        let script = NSAppleScript(source: "do shell script \"\(literal)\" with administrator privileges")
        let result = script?.executeAndReturnError(&error)
        if result == nil || error != nil {
            if error?[NSAppleScript.errorNumber] as? Int == -128 { return }
            let detail = nextBootOnly
                ? "Pour un démarrage unique, choisis ce disque dans les options de démarrage du Mac. "
                    + "Disque de démarrage permet de changer le disque par défaut."
                : "Sélectionne « \(volume.name) » dans Disque de démarrage et confirme le redémarrage. "
                    + "macOS peut demander l’autorisation d’un propriétaire du Mac."
            showSettingsFallback("macOS a refusé le changement de disque.", detail: detail)
            return
        }

        if nextBootOnly {
            let alert = NSAlert()
            alert.messageText = "Prochain démarrage sur « \(volume.name) »"
            alert.informativeText = "Le Mac utilisera ce disque une fois lors du prochain démarrage. "
                + "Laisse le disque branché s’il est externe."
            alert.addButton(withTitle: "OK")
            alert.runModal()
            return
        }

        let loginWindow = NSAppleEventDescriptor(bundleIdentifier: "com.apple.loginwindow")
        let restart = NSAppleEventDescriptor(eventClass: AEEventClass(kCoreEventClass),
                                             eventID: AEEventID(kAEShowRestartDialog),
                                             targetDescriptor: loginWindow,
                                             returnID: AEReturnID(kAutoGenerateReturnID),
                                             transactionID: AETransactionID(kAnyTransactionID))
        do {
            _ = try restart.sendEvent(options: .waitForReply, timeout: 5)
        } catch {
            showSettingsFallback("Le disque de démarrage a été configuré.",
                                 detail: "Pour redémarrer, utilise le menu  > Redémarrer.")
        }
    }

    private func showSettingsFallback(_ title: String, detail: String) {
        let alert = NSAlert()
        alert.messageText = title
        alert.informativeText = detail
        alert.addButton(withTitle: "Ouvrir Disque de démarrage")
        alert.addButton(withTitle: "Fermer").keyEquivalent = "\u{1b}"
        if alert.runModal() == .alertFirstButtonReturn { openStartupSettings() }
    }

    @objc private func openStartupSettings() {
        let url = URL(string: "x-apple.systempreferences:com.apple.Startup-Disk-Settings.extension")!
        if !NSWorkspace.shared.open(url) {
            NSWorkspace.shared.open(URL(fileURLWithPath: "/System/Library/PreferencePanes/StartupDisk.prefPane"))
        }
    }

    @objc private func quit() { NSApp.terminate(nil) }
}

if CommandLine.arguments.contains("--list-volumes") {
    StartupVolume.mounted().forEach { print($0.menuTitle) }
} else {
    let app = NSApplication.shared
    let delegate = MultiBoot()
    app.setActivationPolicy(.accessory)
    app.delegate = delegate
    app.run()
}

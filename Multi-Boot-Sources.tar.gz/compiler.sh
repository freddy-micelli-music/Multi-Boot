#!/bin/bash
set -euo pipefail

project="$(cd "$(dirname "$0")" && pwd)"
build="$(mktemp -d)"
trap 'rm -rf "$build"' EXIT
bundle="$build/Multi-Boot.app"

mkdir -p "$bundle/Contents/MacOS" "$bundle/Contents/Resources"
cp "$project/Sources/Info.plist" "$bundle/Contents/"
cp "$project/Ressources/AppIcon.icns" "$project/Ressources/MenuIcon.png" "$bundle/Contents/Resources/"

for arch in arm64 x86_64; do
    xcrun swiftc -O -module-cache-path "$build/cache" -target "$arch-apple-macos13.0" \
        "$project/Sources/main.swift" -o "$build/Multi-Boot-$arch"
done

lipo -create "$build/Multi-Boot-arm64" "$build/Multi-Boot-x86_64" \
    -output "$bundle/Contents/MacOS/Multi-Boot"
codesign --force --sign - "$bundle"
codesign --verify --strict "$bundle"
ditto -c -k --keepParent "$bundle" "$build/Multi-Boot-compile.zip"
mv "$build/Multi-Boot-compile.zip" "$project/Multi-Boot-compile.zip"
